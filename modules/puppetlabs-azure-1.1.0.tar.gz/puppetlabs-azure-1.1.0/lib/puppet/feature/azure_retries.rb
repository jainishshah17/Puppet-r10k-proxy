require 'puppet/util/feature'

Puppet.features.add(:azure_retries, libs: 'retries')
